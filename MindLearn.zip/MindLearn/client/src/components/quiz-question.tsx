import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface QuizQuestionProps {
  question: {
    question: string;
    options: string[];
    correctAnswer: number;
    explanation: string;
  };
  questionNumber: number;
  selectedAnswer?: number;
  onAnswerSelect: (answerIndex: number) => void;
  showResults?: boolean;
}

export default function QuizQuestion({
  question,
  questionNumber,
  selectedAnswer,
  onAnswerSelect,
  showResults = false
}: QuizQuestionProps) {
  return (
    <Card className="shadow-sm border-slate-200">
      <CardHeader>
        <CardTitle className="text-lg">
          Question {questionNumber}
        </CardTitle>
        <p className="text-slate-700 text-base" data-testid={`question-text-${questionNumber}`}>
          {question.question}
        </p>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {question.options.map((option, index) => {
            let optionClasses = "flex items-start p-4 border rounded-lg cursor-pointer transition-colors";
            
            if (showResults) {
              if (index === question.correctAnswer) {
                optionClasses += " border-accent bg-accent/5";
              } else if (index === selectedAnswer && index !== question.correctAnswer) {
                optionClasses += " border-red-500 bg-red-50";
              } else {
                optionClasses += " border-slate-200 bg-slate-50";
              }
            } else {
              if (selectedAnswer === index) {
                optionClasses += " border-primary bg-primary/5";
              } else {
                optionClasses += " border-slate-200 hover:bg-slate-50";
              }
            }

            return (
              <label 
                key={index} 
                className={optionClasses}
                data-testid={`option-${questionNumber}-${index}`}
              >
                <input
                  type="radio"
                  name={`question-${questionNumber}`}
                  value={index}
                  checked={selectedAnswer === index}
                  onChange={() => onAnswerSelect(index)}
                  className="text-primary focus:ring-primary mt-1"
                  disabled={showResults}
                  data-testid={`radio-${questionNumber}-${index}`}
                />
                <span className="ml-3 text-slate-700 flex-1" data-testid={`option-text-${questionNumber}-${index}`}>
                  {option}
                </span>
                {showResults && index === question.correctAnswer && (
                  <i className="fas fa-check text-accent ml-2"></i>
                )}
                {showResults && index === selectedAnswer && index !== question.correctAnswer && (
                  <i className="fas fa-times text-red-500 ml-2"></i>
                )}
              </label>
            );
          })}
        </div>
        
        {showResults && (
          <div className="mt-4 p-4 bg-slate-50 rounded-lg">
            <h5 className="font-medium text-slate-900 mb-2">Explanation:</h5>
            <p className="text-slate-700 text-sm" data-testid={`explanation-${questionNumber}`}>
              {question.explanation}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
