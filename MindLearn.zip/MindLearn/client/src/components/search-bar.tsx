import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function SearchBar() {
  const [location, setLocation] = useLocation();
  const [query, setQuery] = useState("");
  const { toast } = useToast();

  const searchMutation = useMutation({
    mutationFn: async (searchQuery: string) => {
      const response = await fetch('/api/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ query: searchQuery }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Search failed');
      }

      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Content Generated",
        description: `AI has generated comprehensive content for "${query}"`,
      });
      // Navigate to search results with the generated content
      setLocation('/search');
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      toast({
        title: "Search Error",
        description: error.message || "Failed to search for content",
        variant: "destructive",
      });
    },
  });

  const handleSearch = () => {
    if (!query.trim()) {
      toast({
        title: "Empty Search",
        description: "Please enter a topic to search for",
        variant: "destructive",
      });
      return;
    }

    searchMutation.mutate(query);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const trendingTopics = [
    "Machine Learning",
    "French Language", 
    "Calculus",
    "Biology"
  ];

  return (
    <Card className="shadow-sm border-slate-200">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold text-slate-900 mb-4">Search Any Topic</h3>
        <div className="relative">
          <input
            type="text"
            placeholder="What would you like to learn today? (e.g., Quantum Physics, Spanish Grammar, Web Development...)"
            className="w-full px-6 py-4 pr-12 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent text-lg"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyPress={handleKeyPress}
            disabled={searchMutation.isPending}
            data-testid="input-search-query"
          />
          <button
            className="absolute right-3 top-1/2 transform -translate-y-1/2 p-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50"
            onClick={handleSearch}
            disabled={searchMutation.isPending || !query.trim()}
            data-testid="button-search-submit"
          >
            {searchMutation.isPending ? (
              <i className="fas fa-spinner fa-spin"></i>
            ) : (
              <i className="fas fa-search"></i>
            )}
          </button>
        </div>
        <div className="flex flex-wrap gap-2 mt-4">
          <span className="text-sm text-slate-500">Trending:</span>
          {trendingTopics.map((topic) => (
            <button
              key={topic}
              className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-sm hover:bg-slate-200 transition-colors"
              onClick={() => {
                setQuery(topic);
                searchMutation.mutate(topic);
              }}
              disabled={searchMutation.isPending}
              data-testid={`button-trending-${topic.toLowerCase().replace(' ', '-')}`}
            >
              {topic}
            </button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
