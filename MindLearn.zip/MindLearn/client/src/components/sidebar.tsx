import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";

export default function Sidebar() {
  const [location] = useLocation();
  const { user } = useAuth();

  const navItems = [
    { path: "/", icon: "fas fa-home", label: "Dashboard" },
    { path: "/search", icon: "fas fa-search", label: "Explore Topics" },
    { path: "/progress", icon: "fas fa-chart-line", label: "Progress" },
    { path: "/bookmarks", icon: "fas fa-bookmark", label: "Bookmarks" },
  ];

  return (
    <aside className="w-64 bg-white shadow-lg border-r border-slate-200 flex-shrink-0 flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b border-slate-200">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <i className="fas fa-brain text-white text-lg"></i>
          </div>
          <h1 className="text-xl font-bold text-slate-800">LearnAI</h1>
        </div>
      </div>

      {/* Navigation */}
      <nav className="p-6 space-y-2 flex-1">
        {navItems.map((item) => (
          <Link key={item.path} href={item.path}>
            <a
              className={`flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors ${
                location === item.path
                  ? "bg-primary/10 text-primary"
                  : "text-slate-600 hover:bg-slate-100"
              }`}
              data-testid={`nav-${item.label.toLowerCase().replace(' ', '-')}`}
            >
              <i className={`${item.icon} w-5`}></i>
              <span>{item.label}</span>
            </a>
          </Link>
        ))}
      </nav>

      {/* User Profile */}
      <div className="p-6 border-t border-slate-200">
        <div className="flex items-center space-x-3 p-3 bg-slate-100 rounded-lg mb-4">
          <div className="w-10 h-10 bg-accent rounded-full flex items-center justify-center">
            <span className="text-white font-semibold" data-testid="text-user-initials">
              {(user as any)?.firstName?.charAt(0) || 'U'}
              {(user as any)?.lastName?.charAt(0) || ''}
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-slate-900 truncate" data-testid="text-user-full-name">
              {(user as any)?.firstName || 'User'} {(user as any)?.lastName || ''}
            </p>
            <p className="text-xs text-slate-500" data-testid="text-user-level">
              Level {(user as any)?.level || 1}
            </p>
          </div>
        </div>
        
        <Button
          variant="outline"
          className="w-full justify-start"
          onClick={() => window.location.href = '/api/logout'}
          data-testid="button-logout"
        >
          <i className="fas fa-sign-out-alt mr-2"></i>
          Logout
        </Button>
      </div>
    </aside>
  );
}
