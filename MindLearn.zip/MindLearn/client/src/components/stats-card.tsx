import { Card, CardContent } from "@/components/ui/card";

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: string;
  iconColor: string;
  trend?: string;
  trendColor?: string;
}

export default function StatsCard({
  title,
  value,
  icon,
  iconColor,
  trend,
  trendColor = "text-slate-500"
}: StatsCardProps) {
  return (
    <Card className="shadow-sm border-slate-200">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-600" data-testid={`text-${title.toLowerCase().replace(/\s+/g, '-')}-title`}>
              {title}
            </p>
            <p className="text-3xl font-bold text-slate-900" data-testid={`text-${title.toLowerCase().replace(/\s+/g, '-')}-value`}>
              {value}
            </p>
          </div>
          <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${iconColor}`}>
            <i className={`${icon} text-xl`}></i>
          </div>
        </div>
        {trend && (
          <div className="mt-4 flex items-center text-sm">
            {trend.includes('+') && (
              <i className="fas fa-arrow-up text-accent mr-1"></i>
            )}
            <span className={trendColor} data-testid={`text-${title.toLowerCase().replace(/\s+/g, '-')}-trend`}>
              {trend}
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
