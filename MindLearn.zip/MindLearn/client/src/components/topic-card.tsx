import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import type { Topic } from "@shared/schema";

interface TopicCardProps {
  topic: Topic;
}

export default function TopicCard({ topic }: TopicCardProps) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const bookmarkMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("PATCH", `/api/topics/${topic.id}/bookmark`, { 
        isBookmarked: !topic.isBookmarked 
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/topics"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bookmarks"] });
      toast({
        title: topic.isBookmarked ? "Bookmark Removed" : "Bookmark Added",
        description: `Topic has been ${topic.isBookmarked ? 'removed from' : 'added to'} your bookmarks`,
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update bookmark",
        variant: "destructive",
      });
    },
  });

  const generateQuizMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/topics/${topic.id}/quiz`, {
        method: 'POST',
        credentials: 'include',
      });

      if (!response.ok) {
        throw new Error('Failed to generate quiz');
      }

      return response.json();
    },
    onSuccess: (quiz) => {
      setLocation(`/quiz/${quiz.id}`);
    },
    onError: (error: any) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to generate quiz",
        variant: "destructive",
      });
    },
  });

  const getProgressColor = (progress: number) => {
    if (progress >= 90) return "bg-accent";
    if (progress >= 70) return "bg-primary";
    if (progress >= 40) return "bg-warning";
    return "bg-slate-400";
  };

  return (
    <div 
      className="p-4 border border-slate-200 rounded-lg hover:border-primary/50 transition-colors cursor-pointer"
      data-testid={`topic-card-${topic.id}`}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center space-x-2 mb-2">
            <div className="text-2xl" data-testid={`topic-emoji-${topic.id}`}>
              {topic.emoji}
            </div>
            <h4 className="font-semibold text-slate-900" data-testid={`topic-title-${topic.id}`}>
              {topic.title}
            </h4>
          </div>
          <p className="text-sm text-slate-600 mb-3" data-testid={`topic-subject-${topic.id}`}>
            {topic.subject} • {topic.difficulty}
          </p>
          <div className="flex items-center mb-3">
            <div className="flex-1 bg-slate-200 rounded-full h-2">
              <div 
                className={`h-2 rounded-full transition-all duration-300 ${getProgressColor(topic.progress || 0)}`}
                style={{ width: `${topic.progress || 0}%` }}
                data-testid={`topic-progress-bar-${topic.id}`}
              ></div>
            </div>
            <span className="text-sm text-slate-500 ml-3" data-testid={`topic-progress-${topic.id}`}>
              {topic.progress || 0}%
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">
              <i className="fas fa-clock mr-1"></i>
              {topic.estimatedTime} min
            </span>
            <div className="flex items-center space-x-2">
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  bookmarkMutation.mutate();
                }}
                disabled={bookmarkMutation.isPending}
                className="p-1 text-slate-400 hover:text-warning transition-colors"
                data-testid={`button-bookmark-${topic.id}`}
              >
                <i className={topic.isBookmarked ? "fas fa-bookmark" : "far fa-bookmark"}></i>
              </button>
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  generateQuizMutation.mutate();
                }}
                disabled={generateQuizMutation.isPending}
                className="p-1 text-slate-400 hover:text-primary transition-colors"
                data-testid={`button-start-quiz-${topic.id}`}
              >
                {generateQuizMutation.isPending ? (
                  <i className="fas fa-spinner fa-spin"></i>
                ) : (
                  <i className="fas fa-play"></i>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
