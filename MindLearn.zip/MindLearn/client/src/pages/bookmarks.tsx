import { useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import Sidebar from "@/components/sidebar";
import TopicCard from "@/components/topic-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import type { Topic } from "@shared/schema";

export default function Bookmarks() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: bookmarkedTopics = [], isLoading: bookmarksLoading } = useQuery<Topic[]>({
    queryKey: ["/api/bookmarks"],
    enabled: isAuthenticated,
  });

  const removeBookmarkMutation = useMutation({
    mutationFn: async (topicId: string) => {
      await apiRequest("PATCH", `/api/topics/${topicId}/bookmark`, { isBookmarked: false });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bookmarks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/topics"] });
      toast({
        title: "Bookmark Removed",
        description: "Topic has been removed from your bookmarks",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to remove bookmark",
        variant: "destructive",
      });
    },
  });

  if (isLoading || !isAuthenticated) {
    return null;
  }

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 overflow-auto">
        {/* Header */}
        <header className="bg-white border-b border-slate-200 px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-slate-900">Bookmarked Topics</h2>
              <p className="text-slate-600 mt-1">Your saved learning materials for quick access</p>
            </div>
            <div className="flex items-center space-x-2">
              <span className="px-3 py-1 bg-warning/10 text-warning text-sm font-medium rounded-full">
                {bookmarkedTopics.length} bookmarks
              </span>
            </div>
          </div>
        </header>

        <div className="p-8">
          {bookmarksLoading ? (
            <div className="text-center py-12">
              <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-spinner fa-spin text-white text-xl"></i>
              </div>
              <p className="text-lg font-semibold text-slate-900">Loading bookmarks...</p>
            </div>
          ) : bookmarkedTopics.length === 0 ? (
            <Card className="shadow-sm border-slate-200">
              <CardContent className="p-12">
                <div className="text-center">
                  <div className="w-20 h-20 bg-warning/10 rounded-lg flex items-center justify-center mx-auto mb-6">
                    <i className="fas fa-bookmark text-warning text-3xl"></i>
                  </div>
                  <h3 className="text-xl font-semibold text-slate-900 mb-2">No Bookmarks Yet</h3>
                  <p className="text-slate-600 mb-6 max-w-md mx-auto">
                    Start bookmarking topics you want to revisit later. You can bookmark any topic 
                    from your learning dashboard or search results.
                  </p>
                  <Button className="bg-primary hover:bg-primary/90" data-testid="button-explore-topics">
                    <i className="fas fa-search mr-2"></i>
                    Explore Topics
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              {/* Bookmarks Grid */}
              <div className="grid gap-6">
                {bookmarkedTopics.map((topic) => (
                  <Card key={topic.id} className="shadow-sm border-slate-200" data-testid={`bookmark-${topic.id}`}>
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-4 flex-1">
                          <div className="text-3xl">{topic.emoji}</div>
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <h3 className="text-xl font-semibold text-slate-900" data-testid={`bookmark-title-${topic.id}`}>
                                {topic.title}
                              </h3>
                              <i className="fas fa-bookmark text-warning"></i>
                            </div>
                            <div className="flex items-center space-x-2 mb-3">
                              <span className="px-2 py-1 bg-slate-100 text-slate-700 rounded text-sm">
                                {topic.subject}
                              </span>
                              <span className="px-2 py-1 bg-slate-100 text-slate-700 rounded text-sm">
                                {topic.difficulty}
                              </span>
                              <span className="text-sm text-slate-500">
                                <i className="fas fa-clock mr-1"></i>
                                {topic.estimatedTime} min
                              </span>
                            </div>
                            <p className="text-slate-600 text-sm mb-4 line-clamp-2">
                              {topic.summary}
                            </p>
                            <div className="flex items-center space-x-4">
                              <div className="flex-1">
                                <div className="flex justify-between items-center mb-1">
                                  <span className="text-sm font-medium text-slate-700">Progress</span>
                                  <span className="text-sm text-slate-500">{topic.progress || 0}%</span>
                                </div>
                                <div className="w-full bg-slate-200 rounded-full h-2">
                                  <div 
                                    className="bg-primary h-2 rounded-full transition-all duration-300" 
                                    style={{ width: `${topic.progress || 0}%` }}
                                  ></div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-col space-y-2 ml-4">
                          <Button 
                            variant="outline" 
                            size="sm"
                            data-testid={`button-continue-${topic.id}`}
                          >
                            <i className="fas fa-play mr-2"></i>
                            Continue
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            data-testid={`button-quiz-${topic.id}`}
                          >
                            <i className="fas fa-quiz mr-2"></i>
                            Quiz
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => removeBookmarkMutation.mutate(topic.id)}
                            disabled={removeBookmarkMutation.isPending}
                            className="text-red-600 hover:text-red-700 hover:border-red-300"
                            data-testid={`button-remove-bookmark-${topic.id}`}
                          >
                            {removeBookmarkMutation.isPending ? (
                              <i className="fas fa-spinner fa-spin mr-2"></i>
                            ) : (
                              <i className="fas fa-bookmark-minus mr-2"></i>
                            )}
                            Remove
                          </Button>
                        </div>
                      </div>
                      <div className="mt-4 pt-4 border-t border-slate-200">
                        <div className="flex items-center justify-between text-sm text-slate-500">
                          <span>
                            Bookmarked on {new Date(topic.createdAt!).toLocaleDateString()}
                          </span>
                          <span>
                            Last updated {new Date(topic.updatedAt!).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Quick Actions */}
              <Card className="shadow-sm border-slate-200">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <i className="fas fa-lightning text-warning mr-2"></i>
                    Quick Actions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-3">
                    <Button variant="outline" size="sm" data-testid="button-search-more">
                      <i className="fas fa-search mr-2"></i>
                      Search More Topics
                    </Button>
                    <Button variant="outline" size="sm" data-testid="button-view-progress">
                      <i className="fas fa-chart-line mr-2"></i>
                      View Progress
                    </Button>
                    <Button variant="outline" size="sm" data-testid="button-recommendations">
                      <i className="fas fa-lightbulb mr-2"></i>
                      Get Recommendations
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
