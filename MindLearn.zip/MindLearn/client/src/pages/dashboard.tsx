import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/sidebar";
import SearchBar from "@/components/search-bar";
import StatsCard from "@/components/stats-card";
import TopicCard from "@/components/topic-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { Topic, User } from "@shared/schema";

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: topics = [] } = useQuery<Topic[]>({
    queryKey: ["/api/topics"],
    enabled: isAuthenticated,
  });

  const { data: stats } = useQuery<{
    totalTopics: number;
    studyStreak: number;
    averageScore: number;
    level: number;
  }>({
    queryKey: ["/api/stats"],
    enabled: isAuthenticated,
  });

  const { data: recommendations = [] } = useQuery<Array<{
    title: string;
    description: string;
    subject: string;
    estimatedTime: number;
    matchPercentage: number;
    emoji: string;
  }>>({
    queryKey: ["/api/recommendations"],
    enabled: isAuthenticated,
  });

  const { data: searchHistory = [] } = useQuery<Array<{
    id: string;
    query: string;
    createdAt: string;
    topicId: string | null;
  }>>({
    queryKey: ["/api/search-history"],
    enabled: isAuthenticated,
  });

  if (isLoading || !isAuthenticated) {
    return null;
  }

  const currentTopics = topics.slice(0, 3);

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 overflow-auto">
        {/* Header */}
        <header className="bg-white border-b border-slate-200 px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-slate-900">
                Welcome back, <span data-testid="text-user-name">{(user as any)?.firstName || 'Learner'}</span>!
              </h2>
              <p className="text-slate-600 mt-1">Continue your personalized learning journey</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <button className="p-2 text-slate-400 hover:text-slate-600 transition-colors" data-testid="button-notifications">
                  <i className="fas fa-bell text-xl"></i>
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">3</span>
                </button>
              </div>
              <Button className="bg-primary hover:bg-primary/90" data-testid="button-start-learning">
                <i className="fas fa-plus mr-2"></i>
                Start Learning
              </Button>
            </div>
          </div>
        </header>

        {/* Content */}
        <div className="p-8 space-y-8">
          {/* Search Bar */}
          <SearchBar />

          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <StatsCard
              title="Total Topics"
              value={stats?.totalTopics || 0}
              icon="fas fa-book"
              iconColor="bg-primary/10 text-primary"
              trend={"+3 this week"}
              trendColor="text-accent"
            />
            <StatsCard
              title="Study Streak"
              value={stats?.studyStreak || 0}
              icon="fas fa-fire"
              iconColor="bg-warning/10 text-warning"
              trend="days in a row"
              trendColor="text-slate-500"
            />
            <StatsCard
              title="Avg. Score"
              value={`${stats?.averageScore || 0}%`}
              icon="fas fa-chart-bar"
              iconColor="bg-accent/10 text-accent"
              trend="+5% improvement"
              trendColor="text-accent"
            />
            <StatsCard
              title="Learning Style"
              value={(user as any)?.learningStyle || "Visual"}
              icon="fas fa-eye"
              iconColor="bg-secondary/10 text-secondary"
              trend="Adaptive content"
              trendColor="text-slate-500"
            />
          </div>

          {/* Active Learning */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Current Topics */}
            <Card className="shadow-sm border-slate-200">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg font-semibold text-slate-900">Continue Learning</CardTitle>
                <Button variant="ghost" className="text-primary hover:text-primary/80 text-sm font-medium" data-testid="button-view-all-topics">
                  View All
                </Button>
              </CardHeader>
              <CardContent className="space-y-4">
                {currentTopics.length === 0 ? (
                  <div className="text-center py-8">
                    <div className="w-16 h-16 bg-slate-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                      <i className="fas fa-search text-slate-400 text-xl"></i>
                    </div>
                    <p className="text-slate-600 mb-4">No topics yet. Start by searching for something you'd like to learn!</p>
                  </div>
                ) : (
                  currentTopics.map((topic) => (
                    <TopicCard key={topic.id} topic={topic} />
                  ))
                )}
              </CardContent>
            </Card>

            {/* Sample Quiz Preview */}
            <Card className="shadow-sm border-slate-200">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg font-semibold text-slate-900">Quick Quiz</CardTitle>
                <span className="px-3 py-1 bg-secondary/10 text-secondary text-sm font-medium rounded-full">AI Generated</span>
              </CardHeader>
              <CardContent>
                {currentTopics.length === 0 ? (
                  <div className="text-center py-8">
                    <div className="w-16 h-16 bg-slate-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                      <i className="fas fa-quiz text-slate-400 text-xl"></i>
                    </div>
                    <p className="text-slate-600">Complete a topic to unlock adaptive quizzes!</p>
                  </div>
                ) : (
                  <div className="p-4 bg-slate-50 rounded-lg">
                    <h4 className="font-semibold text-slate-900 mb-3">Ready for a quiz?</h4>
                    <p className="text-slate-700 mb-4">
                      Test your knowledge on {currentTopics[0]?.title} with an AI-generated adaptive quiz.
                    </p>
                    <Button className="w-full" data-testid="button-start-quiz">
                      Start Quiz
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Recent Activity */}
          <Card className="shadow-sm border-slate-200">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg font-semibold text-slate-900">Recent Activity</CardTitle>
              <div className="flex space-x-2">
                <Button variant="default" size="sm" className="bg-primary text-white" data-testid="button-search-history">
                  Search History
                </Button>
                <Button variant="outline" size="sm" data-testid="button-bookmarks">
                  Bookmarks
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {searchHistory.length === 0 ? (
                <div className="text-center py-8">
                  <div className="w-16 h-16 bg-slate-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <i className="fas fa-history text-slate-400 text-xl"></i>
                  </div>
                  <p className="text-slate-600">Your search history will appear here</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {searchHistory.slice(0, 3).map((search) => (
                    <div key={search.id} className="flex items-center justify-between p-3 border border-slate-200 rounded-lg" data-testid={`search-item-${search.id}`}>
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                          <i className="fas fa-search text-primary text-sm"></i>
                        </div>
                        <div>
                          <p className="font-medium text-slate-900" data-testid={`search-query-${search.id}`}>{search.query}</p>
                          <p className="text-sm text-slate-500">
                            {new Date(search.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        {search.topicId && (
                          <>
                            <button className="p-2 text-slate-400 hover:text-warning transition-colors" data-testid={`button-bookmark-${search.id}`}>
                              <i className="fas fa-bookmark"></i>
                            </button>
                            <button className="p-2 text-slate-400 hover:text-primary transition-colors" data-testid={`button-continue-${search.id}`}>
                              <i className="fas fa-play"></i>
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Personalized Recommendations */}
          <Card className="shadow-sm border-slate-200">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg font-semibold text-slate-900">Personalized Recommendations</CardTitle>
              <span className="px-3 py-1 bg-secondary/10 text-secondary text-sm font-medium rounded-full">AI Powered</span>
            </CardHeader>
            <CardContent>
              {recommendations.length === 0 ? (
                <div className="text-center py-8">
                  <div className="w-16 h-16 bg-slate-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <i className="fas fa-lightbulb text-slate-400 text-xl"></i>
                  </div>
                  <p className="text-slate-600">Start learning to get personalized recommendations!</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {recommendations.map((rec, index) => (
                    <div 
                      key={index} 
                      className="p-4 border border-slate-200 rounded-lg hover:border-primary/50 transition-colors cursor-pointer" 
                      data-testid={`recommendation-${index}`}
                    >
                      <div className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center mb-3">
                        <span className="text-white text-xl">{rec.emoji}</span>
                      </div>
                      <h4 className="font-semibold text-slate-900 mb-2" data-testid={`recommendation-title-${index}`}>{rec.title}</h4>
                      <p className="text-sm text-slate-600 mb-3">{rec.description}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-slate-500">Estimated: {rec.estimatedTime} min</span>
                        <span className="text-xs text-primary font-medium">{rec.matchPercentage}% match</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
