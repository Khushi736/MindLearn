import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { Topic, Quiz } from "@shared/schema";

export default function ProgressPage() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading, user } = useAuth();

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: topics = [] } = useQuery<Topic[]>({
    queryKey: ["/api/topics"],
    enabled: isAuthenticated,
  });

  const { data: stats } = useQuery<{
    totalTopics: number;
    studyStreak: number;
    averageScore: number;
    level: number;
  }>({
    queryKey: ["/api/stats"],
    enabled: isAuthenticated,
  });

  if (isLoading || !isAuthenticated) {
    return null;
  }

  const completedTopics = topics.filter(t => (t.progress ?? 0) === 100);
  const inProgressTopics = topics.filter(t => (t.progress ?? 0) > 0 && (t.progress ?? 0) < 100);
  const notStartedTopics = topics.filter(t => (t.progress ?? 0) === 0);

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 overflow-auto">
        {/* Header */}
        <header className="bg-white border-b border-slate-200 px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-slate-900">Learning Progress</h2>
              <p className="text-slate-600 mt-1">Track your learning journey and achievements</p>
            </div>
            <div className="flex items-center space-x-2">
              <Badge className="bg-primary/10 text-primary">
                Level {stats?.level || 1}
              </Badge>
              <Badge className="bg-accent/10 text-accent">
                {stats?.studyStreak || 0} day streak
              </Badge>
            </div>
          </div>
        </header>

        <div className="p-8 space-y-8">
          {/* Overall Progress Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card className="shadow-sm border-slate-200">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-book text-primary text-2xl"></i>
                </div>
                <div className="text-3xl font-bold text-slate-900 mb-2" data-testid="text-total-topics">
                  {stats?.totalTopics || 0}
                </div>
                <p className="text-sm text-slate-600">Total Topics</p>
              </CardContent>
            </Card>

            <Card className="shadow-sm border-slate-200">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-accent/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-check-circle text-accent text-2xl"></i>
                </div>
                <div className="text-3xl font-bold text-slate-900 mb-2" data-testid="text-completed-topics">
                  {completedTopics.length}
                </div>
                <p className="text-sm text-slate-600">Completed</p>
              </CardContent>
            </Card>

            <Card className="shadow-sm border-slate-200">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-warning/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-chart-bar text-warning text-2xl"></i>
                </div>
                <div className="text-3xl font-bold text-slate-900 mb-2" data-testid="text-average-score">
                  {Math.round(stats?.averageScore || 0)}%
                </div>
                <p className="text-sm text-slate-600">Avg Score</p>
              </CardContent>
            </Card>

            <Card className="shadow-sm border-slate-200">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-secondary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-fire text-secondary text-2xl"></i>
                </div>
                <div className="text-3xl font-bold text-slate-900 mb-2" data-testid="text-study-streak">
                  {stats?.studyStreak || 0}
                </div>
                <p className="text-sm text-slate-600">Day Streak</p>
              </CardContent>
            </Card>
          </div>

          {/* Progress by Category */}
          <Card className="shadow-sm border-slate-200">
            <CardHeader>
              <CardTitle className="flex items-center">
                <i className="fas fa-chart-pie text-primary mr-2"></i>
                Progress Overview
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center p-6 bg-accent/5 rounded-lg">
                  <div className="text-2xl font-bold text-accent mb-2">{completedTopics.length}</div>
                  <p className="text-sm text-slate-600 mb-3">Completed Topics</p>
                  <div className="w-full bg-slate-200 rounded-full h-2">
                    <div 
                      className="bg-accent h-2 rounded-full transition-all duration-300"
                      style={{ width: `${topics.length > 0 ? (completedTopics.length / topics.length) * 100 : 0}%` }}
                    ></div>
                  </div>
                </div>

                <div className="text-center p-6 bg-warning/5 rounded-lg">
                  <div className="text-2xl font-bold text-warning mb-2">{inProgressTopics.length}</div>
                  <p className="text-sm text-slate-600 mb-3">In Progress</p>
                  <div className="w-full bg-slate-200 rounded-full h-2">
                    <div 
                      className="bg-warning h-2 rounded-full transition-all duration-300"
                      style={{ width: `${topics.length > 0 ? (inProgressTopics.length / topics.length) * 100 : 0}%` }}
                    ></div>
                  </div>
                </div>

                <div className="text-center p-6 bg-slate-100 rounded-lg">
                  <div className="text-2xl font-bold text-slate-600 mb-2">{notStartedTopics.length}</div>
                  <p className="text-sm text-slate-600 mb-3">Not Started</p>
                  <div className="w-full bg-slate-200 rounded-full h-2">
                    <div 
                      className="bg-slate-400 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${topics.length > 0 ? (notStartedTopics.length / topics.length) * 100 : 0}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Topics Progress List */}
          {topics.length > 0 ? (
            <Card className="shadow-sm border-slate-200">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center">
                    <i className="fas fa-list text-primary mr-2"></i>
                    All Topics
                  </div>
                  <Badge variant="outline">{topics.length} topics</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {topics.map((topic) => (
                    <div 
                      key={topic.id} 
                      className="p-4 border border-slate-200 rounded-lg hover:shadow-sm transition-shadow"
                      data-testid={`topic-item-${topic.id}`}
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div className="text-2xl">{topic.emoji}</div>
                          <div>
                            <h4 className="font-semibold text-slate-900" data-testid={`topic-title-${topic.id}`}>
                              {topic.title}
                            </h4>
                            <div className="flex items-center space-x-2 mt-1">
                              <Badge variant="secondary" className="text-xs">
                                {topic.subject}
                              </Badge>
                              <Badge variant="outline" className="text-xs">
                                {topic.difficulty}
                              </Badge>
                              {topic.isBookmarked && (
                                <i className="fas fa-bookmark text-warning text-sm"></i>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-bold text-slate-900 mb-1">
                            {topic.progress || 0}%
                          </div>
                          <Badge 
                            className={`text-xs ${
                              (topic.progress ?? 0) === 100 
                                ? 'bg-accent text-white' 
                                : (topic.progress ?? 0) > 0 
                                ? 'bg-warning text-white' 
                                : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            {(topic.progress ?? 0) === 100 ? 'Complete' : (topic.progress ?? 0) > 0 ? 'In Progress' : 'Not Started'}
                          </Badge>
                        </div>
                      </div>
                      
                      <div className="mb-3">
                        <Progress value={topic.progress || 0} className="h-2" />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4 text-sm text-slate-500">
                          <span>
                            <i className="fas fa-clock mr-1"></i>
                            {topic.estimatedTime} min
                          </span>
                          <span>
                            Updated {new Date(topic.updatedAt!).toLocaleDateString()}
                          </span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button variant="outline" size="sm" data-testid={`button-continue-${topic.id}`}>
                            <i className="fas fa-play mr-1"></i>
                            Continue
                          </Button>
                          <Button variant="outline" size="sm" data-testid={`button-quiz-${topic.id}`}>
                            <i className="fas fa-quiz mr-1"></i>
                            Quiz
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="shadow-sm border-slate-200">
              <CardContent className="p-12">
                <div className="text-center">
                  <div className="w-20 h-20 bg-slate-100 rounded-lg flex items-center justify-center mx-auto mb-6">
                    <i className="fas fa-chart-line text-slate-400 text-3xl"></i>
                  </div>
                  <h3 className="text-xl font-semibold text-slate-900 mb-2">Start Your Learning Journey</h3>
                  <p className="text-slate-600 mb-6">
                    Begin by searching for topics you're interested in learning about.
                  </p>
                  <Button className="bg-primary hover:bg-primary/90">
                    <i className="fas fa-search mr-2"></i>
                    Search Topics
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}
