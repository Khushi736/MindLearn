import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/sidebar";
import QuizQuestion from "@/components/quiz-question";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";

interface QuizData {
  id: string;
  questions: Array<{
    question: string;
    options: string[];
    correctAnswer: number;
    explanation: string;
  }>;
  totalQuestions: number;
  completed: boolean;
  score?: number;
}

export default function Quiz() {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  
  // Extract quiz ID from URL
  const quizId = location.split('/quiz/')[1];
  
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [quizResults, setQuizResults] = useState<any>(null);
  const [submitting, setSubmitting] = useState(false);

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: quiz, isLoading: quizLoading } = useQuery<QuizData>({
    queryKey: ["/api/quizzes", quizId],
    enabled: isAuthenticated && !!quizId,
  });

  const handleAnswerSelect = (answerIndex: number) => {
    const newAnswers = [...selectedAnswers];
    newAnswers[currentQuestion] = answerIndex;
    setSelectedAnswers(newAnswers);
  };

  const handleNextQuestion = () => {
    if (currentQuestion < (quiz?.totalQuestions || 0) - 1) {
      setCurrentQuestion(currentQuestion + 1);
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const handleSubmitQuiz = async () => {
    if (!quiz || selectedAnswers.length !== quiz.totalQuestions) {
      toast({
        title: "Incomplete Quiz",
        description: "Please answer all questions before submitting",
        variant: "destructive",
      });
      return;
    }

    setSubmitting(true);
    try {
      const response = await fetch(`/api/quizzes/${quiz.id}/submit`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ answers: selectedAnswers }),
      });

      if (!response.ok) {
        throw new Error('Failed to submit quiz');
      }

      const results = await response.json();
      setQuizResults(results);
      
      toast({
        title: "Quiz Submitted!",
        description: `You scored ${results.score}% (${results.correct}/${results.total})`,
        variant: results.score >= 70 ? "default" : "destructive",
      });
    } catch (error: any) {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      toast({
        title: "Error",
        description: "Failed to submit quiz",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (isLoading || !isAuthenticated || quizLoading) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mx-auto mb-4">
            <i className="fas fa-quiz text-white text-xl"></i>
          </div>
          <p className="text-lg font-semibold text-slate-900">Loading Quiz...</p>
        </div>
      </div>
    );
  }

  if (!quiz) {
    return (
      <div className="flex h-screen overflow-hidden">
        <Sidebar />
        <main className="flex-1 overflow-auto flex items-center justify-center">
          <Card className="w-full max-w-md mx-4">
            <CardContent className="pt-6 text-center">
              <div className="w-16 h-16 bg-red-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-exclamation-triangle text-red-500 text-xl"></i>
              </div>
              <h3 className="text-lg font-semibold text-slate-900 mb-2">Quiz Not Found</h3>
              <p className="text-slate-600 mb-4">The requested quiz could not be found.</p>
              <Button onClick={() => setLocation('/')}>Back to Dashboard</Button>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  // Show results if quiz is completed
  if (quizResults) {
    return (
      <div className="flex h-screen overflow-hidden">
        <Sidebar />
        <main className="flex-1 overflow-auto">
          <div className="p-8 max-w-4xl mx-auto">
            <Card className="mb-8">
              <CardHeader className="text-center">
                <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 ${
                  quizResults.score >= 70 ? 'bg-accent/10' : 'bg-red-100'
                }`}>
                  <i className={`text-3xl ${
                    quizResults.score >= 70 ? 'fas fa-check text-accent' : 'fas fa-times text-red-500'
                  }`}></i>
                </div>
                <CardTitle className="text-2xl text-slate-900">Quiz Complete!</CardTitle>
                <div className="flex items-center justify-center space-x-4 mt-4">
                  <Badge className={`text-lg px-4 py-2 ${
                    quizResults.score >= 70 ? 'bg-accent' : 'bg-red-500'
                  }`}>
                    Score: {quizResults.score}%
                  </Badge>
                  <span className="text-slate-600">
                    {quizResults.correct} out of {quizResults.total} correct
                  </span>
                </div>
              </CardHeader>
            </Card>

            {/* Results Breakdown */}
            <div className="space-y-6">
              {quizResults.results.map((result: any, index: number) => (
                <Card key={index} className={`border-l-4 ${
                  result.isCorrect ? 'border-l-accent' : 'border-l-red-500'
                }`}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <CardTitle className="text-lg">Question {index + 1}</CardTitle>
                      <Badge variant={result.isCorrect ? "default" : "destructive"}>
                        {result.isCorrect ? 'Correct' : 'Incorrect'}
                      </Badge>
                    </div>
                    <p className="text-slate-700">{result.question}</p>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div>
                        <span className="text-sm font-medium text-slate-600">Your Answer: </span>
                        <span className={`font-medium ${
                          result.isCorrect ? 'text-accent' : 'text-red-500'
                        }`}>
                          {quiz.questions[index]?.options[result.userAnswer] || 'No answer'}
                        </span>
                      </div>
                      {!result.isCorrect && (
                        <div>
                          <span className="text-sm font-medium text-slate-600">Correct Answer: </span>
                          <span className="font-medium text-accent">
                            {quiz.questions[index]?.options[result.correctAnswer]}
                          </span>
                        </div>
                      )}
                      <div className="p-3 bg-slate-50 rounded-lg">
                        <span className="text-sm font-medium text-slate-600">Explanation: </span>
                        <p className="text-slate-700 mt-1">{result.explanation}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="flex justify-center mt-8 space-x-4">
              <Button variant="outline" onClick={() => setLocation('/')}>
                <i className="fas fa-home mr-2"></i>
                Back to Dashboard
              </Button>
              <Button onClick={() => window.location.reload()}>
                <i className="fas fa-redo mr-2"></i>
                Retake Quiz
              </Button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  const currentQ = quiz.questions[currentQuestion];
  const progress = ((currentQuestion + 1) / quiz.totalQuestions) * 100;

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 overflow-auto">
        {/* Header */}
        <header className="bg-white border-b border-slate-200 px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-slate-900">Adaptive Quiz</h2>
              <p className="text-slate-600 mt-1">Question {currentQuestion + 1} of {quiz.totalQuestions}</p>
            </div>
            <Button variant="outline" onClick={() => setLocation('/')}>
              <i className="fas fa-times mr-2"></i>
              Exit Quiz
            </Button>
          </div>
        </header>

        <div className="p-8 max-w-4xl mx-auto">
          {/* Progress */}
          <Card className="mb-8">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-slate-700">Progress</span>
                <span className="text-sm text-slate-500">{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-3" />
              <div className="flex justify-center mt-4">
                <div className="flex space-x-2">
                  {Array.from({ length: quiz.totalQuestions }).map((_, index) => (
                    <div
                      key={index}
                      className={`w-3 h-3 rounded-full ${
                        index < currentQuestion 
                          ? 'bg-accent' 
                          : index === currentQuestion 
                          ? 'bg-primary' 
                          : 'bg-slate-200'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Question */}
          <QuizQuestion
            question={currentQ}
            questionNumber={currentQuestion + 1}
            selectedAnswer={selectedAnswers[currentQuestion]}
            onAnswerSelect={handleAnswerSelect}
          />

          {/* Navigation */}
          <Card className="mt-8">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <Button
                  variant="outline"
                  onClick={handlePreviousQuestion}
                  disabled={currentQuestion === 0}
                  data-testid="button-previous-question"
                >
                  <i className="fas fa-chevron-left mr-2"></i>
                  Previous
                </Button>

                <div className="text-center">
                  <p className="text-sm text-slate-600 mb-1">
                    {selectedAnswers.filter(a => a !== undefined).length} of {quiz.totalQuestions} answered
                  </p>
                  {selectedAnswers[currentQuestion] !== undefined && (
                    <Badge variant="outline">Answer Selected</Badge>
                  )}
                </div>

                {currentQuestion === quiz.totalQuestions - 1 ? (
                  <Button
                    onClick={handleSubmitQuiz}
                    disabled={submitting || selectedAnswers.length !== quiz.totalQuestions}
                    className="bg-accent hover:bg-accent/90"
                    data-testid="button-submit-quiz"
                  >
                    {submitting ? (
                      <>
                        <i className="fas fa-spinner fa-spin mr-2"></i>
                        Submitting...
                      </>
                    ) : (
                      <>
                        <i className="fas fa-check mr-2"></i>
                        Submit Quiz
                      </>
                    )}
                  </Button>
                ) : (
                  <Button
                    onClick={handleNextQuestion}
                    disabled={selectedAnswers[currentQuestion] === undefined}
                    data-testid="button-next-question"
                  >
                    Next
                    <i className="fas fa-chevron-right ml-2"></i>
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
