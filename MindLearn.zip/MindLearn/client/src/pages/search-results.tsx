import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export default function SearchResults() {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [searchResults, setSearchResults] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const handleSearch = async (query: string) => {
    if (!query.trim()) return;

    setLoading(true);
    try {
      const response = await fetch('/api/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ query }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Search failed');
      }

      const data = await response.json();
      setSearchResults(data);
      
      toast({
        title: "Content Generated",
        description: `AI has generated comprehensive content for "${query}"`,
      });
    } catch (error: any) {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      toast({
        title: "Search Error",
        description: error.message || "Failed to search for content",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const generateQuiz = async () => {
    if (!searchResults?.topic?.id) return;

    try {
      const response = await fetch(`/api/topics/${searchResults.topic.id}/quiz`, {
        method: 'POST',
        credentials: 'include',
      });

      if (!response.ok) {
        throw new Error('Failed to generate quiz');
      }

      const quiz = await response.json();
      setLocation(`/quiz/${quiz.id}`);
    } catch (error: any) {
      toast({
        title: "Error",
        description: "Failed to generate quiz",
        variant: "destructive",
      });
    }
  };

  if (isLoading || !isAuthenticated) {
    return null;
  }

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 overflow-auto">
        {/* Header */}
        <header className="bg-white border-b border-slate-200 px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-slate-900">Search Results</h2>
              <p className="text-slate-600 mt-1">AI-generated educational content</p>
            </div>
            <Button 
              variant="outline" 
              onClick={() => setLocation('/')}
              data-testid="button-back-dashboard"
            >
              <i className="fas fa-arrow-left mr-2"></i>
              Back to Dashboard
            </Button>
          </div>
        </header>

        <div className="p-8 max-w-5xl mx-auto">
          {/* Search Bar */}
          <Card className="mb-8 shadow-sm border-slate-200">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold text-slate-900 mb-4">Search Any Topic</h3>
              <div className="relative">
                <input
                  type="text"
                  placeholder="What would you like to learn today?"
                  className="w-full px-6 py-4 pr-12 border border-slate-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent text-lg"
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      handleSearch((e.target as HTMLInputElement).value);
                    }
                  }}
                  disabled={loading}
                  data-testid="input-search"
                />
                <button 
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 p-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50"
                  disabled={loading}
                  onClick={() => {
                    const input = document.querySelector('[data-testid="input-search"]') as HTMLInputElement;
                    if (input) handleSearch(input.value);
                  }}
                  data-testid="button-search"
                >
                  {loading ? (
                    <i className="fas fa-spinner fa-spin"></i>
                  ) : (
                    <i className="fas fa-search"></i>
                  )}
                </button>
              </div>
            </CardContent>
          </Card>

          {/* Loading State */}
          {loading && (
            <Card className="mb-8">
              <CardContent className="p-8">
                <div className="text-center">
                  <div className="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <i className="fas fa-brain text-primary text-2xl animate-pulse"></i>
                  </div>
                  <h3 className="text-xl font-semibold text-slate-900 mb-2">AI is generating content...</h3>
                  <p className="text-slate-600">This may take a few moments</p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Search Results */}
          {searchResults && (
            <div className="space-y-8">
              {/* Topic Header */}
              <Card className="shadow-sm border-slate-200">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="text-4xl">{searchResults.generatedContent.emoji}</div>
                      <div>
                        <CardTitle className="text-2xl text-slate-900" data-testid="text-topic-title">
                          {searchResults.topic.title}
                        </CardTitle>
                        <div className="flex items-center space-x-2 mt-2">
                          <Badge variant="secondary">{searchResults.topic.subject}</Badge>
                          <Badge variant="outline">{searchResults.topic.difficulty}</Badge>
                          <span className="text-sm text-slate-500">
                            <i className="fas fa-clock mr-1"></i>
                            {searchResults.topic.estimatedTime} min
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button variant="outline" data-testid="button-bookmark">
                        <i className="far fa-bookmark mr-2"></i>
                        Bookmark
                      </Button>
                      <Button onClick={generateQuiz} data-testid="button-generate-quiz">
                        <i className="fas fa-quiz mr-2"></i>
                        Generate Quiz
                      </Button>
                    </div>
                  </div>
                </CardHeader>
              </Card>

              {/* Summary */}
              <Card className="shadow-sm border-slate-200">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <i className="fas fa-lightbulb text-warning mr-2"></i>
                    Summary
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-700 leading-relaxed" data-testid="text-summary">
                    {searchResults.generatedContent.summary}
                  </p>
                </CardContent>
              </Card>

              {/* Main Content */}
              <Card className="shadow-sm border-slate-200">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <i className="fas fa-book text-primary mr-2"></i>
                    Detailed Content
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="prose prose-slate max-w-none" data-testid="text-content">
                    {searchResults.generatedContent.content.split('\n\n').map((paragraph: string, index: number) => (
                      <p key={index} className="mb-4 text-slate-700 leading-relaxed">
                        {paragraph}
                      </p>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Progress Tracker */}
              <Card className="shadow-sm border-slate-200">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <i className="fas fa-chart-line text-accent mr-2"></i>
                    Learning Progress
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium text-slate-700">Reading Progress</span>
                        <span className="text-sm text-slate-500">{searchResults.topic.progress || 0}%</span>
                      </div>
                      <Progress value={searchResults.topic.progress || 0} className="h-2" />
                    </div>
                    
                    <div className="flex items-center justify-between pt-4">
                      <Button variant="outline" data-testid="button-mark-read">
                        <i className="fas fa-check mr-2"></i>
                        Mark as Read
                      </Button>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm" data-testid="button-previous">
                          <i className="fas fa-chevron-left"></i>
                        </Button>
                        <Button variant="outline" size="sm" data-testid="button-next">
                          <i className="fas fa-chevron-right"></i>
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Empty State */}
          {!searchResults && !loading && (
            <Card className="shadow-sm border-slate-200">
              <CardContent className="p-12">
                <div className="text-center">
                  <div className="w-20 h-20 bg-slate-100 rounded-lg flex items-center justify-center mx-auto mb-6">
                    <i className="fas fa-search text-slate-400 text-3xl"></i>
                  </div>
                  <h3 className="text-xl font-semibold text-slate-900 mb-2">Start Your Learning Journey</h3>
                  <p className="text-slate-600 mb-6 max-w-md mx-auto">
                    Search for any topic and get comprehensive, AI-generated educational content 
                    tailored to your learning level and style.
                  </p>
                  <div className="flex flex-wrap gap-2 justify-center">
                    <span className="text-sm text-slate-500">Try searching for:</span>
                    <Button variant="outline" size="sm" onClick={() => handleSearch("Machine Learning")}>
                      Machine Learning
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => handleSearch("Quantum Physics")}>
                      Quantum Physics
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => handleSearch("Spanish Grammar")}>
                      Spanish Grammar
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}
