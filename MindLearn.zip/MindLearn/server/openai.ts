import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.VITE_OPENAI_API_KEY || "default_key"
});

export interface GeneratedContent {
  title: string;
  subject: string;
  difficulty: "beginner" | "intermediate" | "advanced";
  content: string;
  summary: string;
  estimatedTime: number;
  emoji: string;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface GeneratedQuiz {
  questions: QuizQuestion[];
  totalQuestions: number;
}

export async function generateTopicContent(query: string, userLevel = "beginner"): Promise<GeneratedContent> {
  try {
    const prompt = `You are an expert educational content generator. Create comprehensive learning content for the topic: "${query}".

User Level: ${userLevel}

Generate content that includes:
1. A clear, engaging title
2. Subject category (e.g., Mathematics, Physics, Computer Science, History, etc.)
3. Appropriate difficulty level
4. Detailed educational content (aim for 500-800 words)
5. A concise summary (100-150 words)
6. Estimated reading/learning time in minutes
7. An appropriate emoji for the topic

Adapt the content complexity to the user's level. For beginners, focus on fundamentals and clear explanations. For advanced users, include more technical details and nuanced concepts.

Respond with JSON in this exact format: {
  "title": "string",
  "subject": "string", 
  "difficulty": "beginner|intermediate|advanced",
  "content": "string",
  "summary": "string",
  "estimatedTime": number,
  "emoji": "string"
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      temperature: 0.7,
    });

    const result = JSON.parse(response.choices[0].message.content!);
    return result as GeneratedContent;
  } catch (error) {
    throw new Error(`Failed to generate content: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

export async function generateQuiz(topicContent: string, difficulty = "beginner", questionCount = 5): Promise<GeneratedQuiz> {
  try {
    const prompt = `You are an expert quiz generator. Create a ${difficulty} level quiz based on this educational content:

"${topicContent.substring(0, 1500)}..."

Generate ${questionCount} multiple choice questions that:
1. Test understanding of key concepts
2. Are appropriate for ${difficulty} level
3. Have 4 answer options each
4. Include clear explanations for correct answers
5. Progress from basic recall to application/analysis

Respond with JSON in this exact format: {
  "questions": [
    {
      "question": "string",
      "options": ["option1", "option2", "option3", "option4"],
      "correctAnswer": number (0-3 index),
      "explanation": "string"
    }
  ],
  "totalQuestions": number
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      temperature: 0.8,
    });

    const result = JSON.parse(response.choices[0].message.content!);
    return result as GeneratedQuiz;
  } catch (error) {
    throw new Error(`Failed to generate quiz: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

export async function generatePersonalizedRecommendations(
  userTopics: string[], 
  searchHistory: string[], 
  learningStyle = "visual",
  count = 3
): Promise<Array<{
  title: string;
  description: string;
  subject: string;
  estimatedTime: number;
  matchPercentage: number;
  emoji: string;
}>> {
  try {
    const prompt = `You are an AI learning recommendation system. Generate ${count} personalized learning recommendations based on:

User's Current Topics: ${userTopics.join(", ")}
Recent Searches: ${searchHistory.join(", ")}
Learning Style: ${learningStyle}

Generate recommendations that:
1. Build upon existing knowledge
2. Fill knowledge gaps
3. Introduce complementary subjects
4. Match the user's learning style preferences
5. Provide natural progression paths

For each recommendation, calculate a realistic match percentage (70-98%) based on relevance to user's interests and learning pattern.

Respond with JSON in this exact format: {
  "recommendations": [
    {
      "title": "string",
      "description": "string (2-3 sentences)",
      "subject": "string",
      "estimatedTime": number (in minutes),
      "matchPercentage": number (70-98),
      "emoji": "string"
    }
  ]
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      temperature: 0.9,
    });

    const result = JSON.parse(response.choices[0].message.content!);
    return result.recommendations;
  } catch (error) {
    throw new Error(`Failed to generate recommendations: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

export async function generateExplanation(
  question: string, 
  userAnswer: string, 
  correctAnswer: string,
  context: string
): Promise<string> {
  try {
    const prompt = `You are an expert tutor providing personalized explanations. A student answered a question incorrectly and needs help understanding.

Question: ${question}
Student's Answer: ${userAnswer}
Correct Answer: ${correctAnswer}
Learning Context: ${context.substring(0, 500)}

Provide a clear, encouraging explanation that:
1. Explains why the correct answer is right
2. Addresses the student's misconception (if applicable)
3. Provides additional context from the learning material
4. Uses simple, clear language
5. Ends with an encouraging note

Keep the explanation concise but comprehensive (2-3 paragraphs).`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.6,
    });

    return response.choices[0].message.content!;
  } catch (error) {
    throw new Error(`Failed to generate explanation: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}
