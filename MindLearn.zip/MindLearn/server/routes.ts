import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertTopicSchema, insertSearchSchema, insertQuizSchema } from "@shared/schema";
import { 
  generateTopicContent, 
  generateQuiz, 
  generatePersonalizedRecommendations,
  generateExplanation
} from "./openai";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Search and content generation
  app.post("/api/search", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { query } = req.body;

      if (!query || query.trim().length === 0) {
        return res.status(400).json({ message: "Search query is required" });
      }

      // Generate AI content for the search query
      const user = await storage.getUser(userId);
      const userLevel = user?.level && user.level > 10 ? "advanced" : user?.level && user.level > 5 ? "intermediate" : "beginner";
      
      const generatedContent = await generateTopicContent(query, userLevel);
      
      // Create topic
      const topic = await storage.createTopic({
        userId,
        title: generatedContent.title,
        subject: generatedContent.subject,
        difficulty: generatedContent.difficulty,
        content: generatedContent.content,
        summary: generatedContent.summary,
        emoji: generatedContent.emoji,
        estimatedTime: generatedContent.estimatedTime,
      });

      // Save search
      await storage.createSearch({
        userId,
        query,
        topicId: topic.id,
      });

      res.json({ topic, generatedContent });
    } catch (error) {
      console.error("Search error:", error);
      res.status(500).json({ message: "Failed to process search" });
    }
  });

  // Get user topics
  app.get("/api/topics", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const topics = await storage.getUserTopics(userId);
      res.json(topics);
    } catch (error) {
      console.error("Error fetching topics:", error);
      res.status(500).json({ message: "Failed to fetch topics" });
    }
  });

  // Get single topic
  app.get("/api/topics/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const topic = await storage.getTopic(id);
      
      if (!topic) {
        return res.status(404).json({ message: "Topic not found" });
      }

      // Check if user owns this topic
      const userId = req.user.claims.sub;
      if (topic.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      res.json(topic);
    } catch (error) {
      console.error("Error fetching topic:", error);
      res.status(500).json({ message: "Failed to fetch topic" });
    }
  });

  // Update topic progress
  app.patch("/api/topics/:id/progress", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { progress } = req.body;
      
      if (typeof progress !== "number" || progress < 0 || progress > 100) {
        return res.status(400).json({ message: "Progress must be a number between 0 and 100" });
      }

      await storage.updateTopicProgress(id, progress);
      res.json({ message: "Progress updated successfully" });
    } catch (error) {
      console.error("Error updating progress:", error);
      res.status(500).json({ message: "Failed to update progress" });
    }
  });

  // Toggle bookmark
  app.patch("/api/topics/:id/bookmark", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { isBookmarked } = req.body;

      await storage.toggleBookmark(id, isBookmarked);
      res.json({ message: "Bookmark updated successfully" });
    } catch (error) {
      console.error("Error updating bookmark:", error);
      res.status(500).json({ message: "Failed to update bookmark" });
    }
  });

  // Get bookmarked topics
  app.get("/api/bookmarks", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const bookmarkedTopics = await storage.getBookmarkedTopics(userId);
      res.json(bookmarkedTopics);
    } catch (error) {
      console.error("Error fetching bookmarks:", error);
      res.status(500).json({ message: "Failed to fetch bookmarks" });
    }
  });

  // Generate quiz for topic
  app.post("/api/topics/:id/quiz", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      const topic = await storage.getTopic(id);
      if (!topic || topic.userId !== userId) {
        return res.status(404).json({ message: "Topic not found" });
      }

      const generatedQuiz = await generateQuiz(topic.content ?? '', topic.difficulty, 5);
      
      const quiz = await storage.createQuiz({
        topicId: id,
        userId,
        questions: generatedQuiz.questions,
        totalQuestions: generatedQuiz.totalQuestions,
      });

      res.json(quiz);
    } catch (error) {
      console.error("Error generating quiz:", error);
      res.status(500).json({ message: "Failed to generate quiz" });
    }
  });

  // Get quiz
  app.get("/api/quizzes/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      const quiz = await storage.getQuiz(id);
      if (!quiz || quiz.userId !== userId) {
        return res.status(404).json({ message: "Quiz not found" });
      }

      res.json(quiz);
    } catch (error) {
      console.error("Error fetching quiz:", error);
      res.status(500).json({ message: "Failed to fetch quiz" });
    }
  });

  // Submit quiz answer
  app.post("/api/quizzes/:id/submit", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { answers } = req.body; // Array of selected answer indices
      const userId = req.user.claims.sub;

      const quiz = await storage.getQuiz(id);
      if (!quiz || quiz.userId !== userId) {
        return res.status(404).json({ message: "Quiz not found" });
      }

      // Calculate score
      const questions = quiz.questions as any[];
      let correct = 0;
      const results = questions.map((question, index) => {
        const isCorrect = answers[index] === question.correctAnswer;
        if (isCorrect) correct++;
        
        return {
          question: question.question,
          userAnswer: answers[index],
          correctAnswer: question.correctAnswer,
          isCorrect,
          explanation: question.explanation,
        };
      });

      const score = Math.round((correct / questions.length) * 100);
      
      await storage.updateQuizScore(id, score, true);
      
      res.json({
        score,
        correct,
        total: questions.length,
        results,
      });
    } catch (error) {
      console.error("Error submitting quiz:", error);
      res.status(500).json({ message: "Failed to submit quiz" });
    }
  });

  // Get search history
  app.get("/api/search-history", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const searchHistory = await storage.getUserSearchHistory(userId);
      res.json(searchHistory);
    } catch (error) {
      console.error("Error fetching search history:", error);
      res.status(500).json({ message: "Failed to fetch search history" });
    }
  });

  // Get user statistics
  app.get("/api/stats", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getUserStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Get personalized recommendations
  app.get("/api/recommendations", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Get user's topics and search history
      const topics = await storage.getUserTopics(userId, 5);
      const searches = await storage.getUserSearchHistory(userId, 10);
      const user = await storage.getUser(userId);
      
      const topicTitles = topics.map(t => t.title);
      const searchQueries = searches.map(s => s.query);
      
      const recommendations = await generatePersonalizedRecommendations(
        topicTitles,
        searchQueries,
        user?.learningStyle || "visual"
      );

      res.json(recommendations);
    } catch (error) {
      console.error("Error generating recommendations:", error);
      res.status(500).json({ message: "Failed to generate recommendations" });
    }
  });

  // Create topic from recommendation
  app.post("/api/recommendations/create-topic", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { title } = req.body;

      if (!title) {
        return res.status(400).json({ message: "Title is required" });
      }

      // Generate content for the recommended topic
      const user = await storage.getUser(userId);
      const userLevel = user?.level && user.level > 10 ? "advanced" : user?.level && user.level > 5 ? "intermediate" : "beginner";
      
      const generatedContent = await generateTopicContent(title, userLevel);
      
      const topic = await storage.createTopic({
        userId,
        title: generatedContent.title,
        subject: generatedContent.subject,
        difficulty: generatedContent.difficulty,
        content: generatedContent.content,
        summary: generatedContent.summary,
        emoji: generatedContent.emoji,
        estimatedTime: generatedContent.estimatedTime,
      });

      res.json({ topic, generatedContent });
    } catch (error) {
      console.error("Error creating topic from recommendation:", error);
      res.status(500).json({ message: "Failed to create topic" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
