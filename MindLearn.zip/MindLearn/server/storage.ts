import {
  users,
  topics,
  searches,
  quizzes,
  userProgress,
  type User,
  type UpsertUser,
  type Topic,
  type InsertTopic,
  type Search,
  type InsertSearch,
  type Quiz,
  type InsertQuiz,
  type UserProgress,
  type InsertUserProgress,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Topic operations
  createTopic(topic: InsertTopic): Promise<Topic>;
  getTopic(id: string): Promise<Topic | undefined>;
  getUserTopics(userId: string, limit?: number): Promise<Topic[]>;
  updateTopicProgress(topicId: string, progress: number): Promise<void>;
  toggleBookmark(topicId: string, isBookmarked: boolean): Promise<void>;
  getBookmarkedTopics(userId: string): Promise<Topic[]>;
  
  // Search operations
  createSearch(search: InsertSearch): Promise<Search>;
  getUserSearchHistory(userId: string, limit?: number): Promise<Search[]>;
  
  // Quiz operations
  createQuiz(quiz: InsertQuiz): Promise<Quiz>;
  getQuiz(id: string): Promise<Quiz | undefined>;
  updateQuizScore(quizId: string, score: number, completed: boolean): Promise<void>;
  getUserQuizzes(userId: string): Promise<Quiz[]>;
  
  // Progress operations
  createOrUpdateProgress(progress: InsertUserProgress): Promise<UserProgress>;
  getUserProgress(userId: string, topicId: string): Promise<UserProgress | undefined>;
  
  // Analytics
  getUserStats(userId: string): Promise<{
    totalTopics: number;
    studyStreak: number;
    averageScore: number;
    level: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Topic operations
  async createTopic(topic: InsertTopic): Promise<Topic> {
    const [newTopic] = await db.insert(topics).values(topic).returning();
    
    // Update user's total topics count
    await db
      .update(users)
      .set({ 
        totalTopics: sql`${users.totalTopics} + 1`,
        updatedAt: new Date(),
      })
      .where(eq(users.id, topic.userId));
      
    return newTopic;
  }

  async getTopic(id: string): Promise<Topic | undefined> {
    const [topic] = await db.select().from(topics).where(eq(topics.id, id));
    return topic;
  }

  async getUserTopics(userId: string, limit = 10): Promise<Topic[]> {
    return await db
      .select()
      .from(topics)
      .where(eq(topics.userId, userId))
      .orderBy(desc(topics.updatedAt))
      .limit(limit);
  }

  async updateTopicProgress(topicId: string, progress: number): Promise<void> {
    await db
      .update(topics)
      .set({ 
        progress,
        updatedAt: new Date(),
      })
      .where(eq(topics.id, topicId));
  }

  async toggleBookmark(topicId: string, isBookmarked: boolean): Promise<void> {
    await db
      .update(topics)
      .set({ 
        isBookmarked,
        updatedAt: new Date(),
      })
      .where(eq(topics.id, topicId));
  }

  async getBookmarkedTopics(userId: string): Promise<Topic[]> {
    return await db
      .select()
      .from(topics)
      .where(and(eq(topics.userId, userId), eq(topics.isBookmarked, true)))
      .orderBy(desc(topics.updatedAt));
  }

  // Search operations
  async createSearch(search: InsertSearch): Promise<Search> {
    const [newSearch] = await db.insert(searches).values(search).returning();
    return newSearch;
  }

  async getUserSearchHistory(userId: string, limit = 20): Promise<Search[]> {
    return await db
      .select()
      .from(searches)
      .where(eq(searches.userId, userId))
      .orderBy(desc(searches.createdAt))
      .limit(limit);
  }

  // Quiz operations
  async createQuiz(quiz: InsertQuiz): Promise<Quiz> {
    const [newQuiz] = await db.insert(quizzes).values(quiz).returning();
    return newQuiz;
  }

  async getQuiz(id: string): Promise<Quiz | undefined> {
    const [quiz] = await db.select().from(quizzes).where(eq(quizzes.id, id));
    return quiz;
  }

  async updateQuizScore(quizId: string, score: number, completed: boolean): Promise<void> {
    const updateData: any = { score, completed };
    if (completed) {
      updateData.completedAt = new Date();
    }
    
    await db
      .update(quizzes)
      .set(updateData)
      .where(eq(quizzes.id, quizId));
  }

  async getUserQuizzes(userId: string): Promise<Quiz[]> {
    return await db
      .select()
      .from(quizzes)
      .where(eq(quizzes.userId, userId))
      .orderBy(desc(quizzes.createdAt));
  }

  // Progress operations
  async createOrUpdateProgress(progress: InsertUserProgress): Promise<UserProgress> {
    const [existingProgress] = await db
      .select()
      .from(userProgress)
      .where(
        and(
          eq(userProgress.userId, progress.userId),
          eq(userProgress.topicId, progress.topicId)
        )
      );

    if (existingProgress) {
      const [updated] = await db
        .update(userProgress)
        .set({
          ...progress,
          updatedAt: new Date(),
        })
        .where(eq(userProgress.id, existingProgress.id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(userProgress).values(progress).returning();
      return created;
    }
  }

  async getUserProgress(userId: string, topicId: string): Promise<UserProgress | undefined> {
    const [progress] = await db
      .select()
      .from(userProgress)
      .where(
        and(
          eq(userProgress.userId, userId),
          eq(userProgress.topicId, topicId)
        )
      );
    return progress;
  }

  // Analytics
  async getUserStats(userId: string): Promise<{
    totalTopics: number;
    studyStreak: number;
    averageScore: number;
    level: number;
  }> {
    const [user] = await db.select().from(users).where(eq(users.id, userId));
    
    if (!user) {
      return { totalTopics: 0, studyStreak: 0, averageScore: 0, level: 1 };
    }

    return {
      totalTopics: user.totalTopics || 0,
      studyStreak: user.studyStreak || 0,
      averageScore: user.averageScore || 0,
      level: user.level || 1,
    };
  }
}

export const storage = new DatabaseStorage();
